<!DOCTYPE html>
<html>
<title>Emissor de Recibos</title>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">

<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">



<body>

	<div class=" w3-border w3-mobile w3-round-large w3-padding-large w3-xlarge w3-orange "
		href="ajuCadastro.php"
		style="width: 100%;">
		Como cadastrar um cliente
	</div>
	
	<div class="w3-card-4 w3-large w3-amber w3-container "
		 href="ajuRecibo.php">

		<ul> 1- Clique em "Cadastro </ul>
		<ul> 2- Clique em Incluir</ul>
		<ul> 3- Preencha os dados necessários</ul>
		<ul> 4- Confirme</ul>
		<ul></ul>
		
	</div>

	<a 	class="w3-button w3-border w3-mobile w3-round-large w3-padding-large w3-xlarge w3-hover-dark-gray w3-yellow "
		style="width: 100%;"
		href="aju.php">

		<i class="material-icons w3-xxlarge w3-cell-middle w3-left">home</i>
		Voltar
	</a>

</body>

</html>