<!DOCTYPE html>
<html>
<title>Emissor de Recibos</title>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">

<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">

<link rel="stylesheet" type="text/css" href="i_style.css">

<body>
	<div class="w3-container w3-teal">
	  <h1>Emissor de Recibos</h1>
	</div>
	

<?php

include("i_conecta_clientes.php");

// recebe os parametros do html
$cpf 			= $_POST['input_cpf'];
$nome 			= $_POST['input_nome'];
$endereco 		= $_POST['input_endereco'];
$datanascimento = $_POST['input_datanascimento'];
$email 			= $_POST['input_email'];
$telefone		= $_POST['input_telefone'];
$cpf_titular	= $_POST['input_cpf_titular'];

// cria comando para inserir dados
$sql = "INSERT INTO $tb_clientes (cpf, nome, endereco, datanascimento, email, telefone, cpf_titular)
					VALUES ('$cpf','$nome','$endereco','$datanascimento','$email','$telefone','$cpf_titular')";

// executa e verifica resultado
if ($conn_cli->query($sql) === TRUE) {
	// fecha banco
	$conn_cli->close();

	header("location: msg_sucesso.php?destino='index.htm'");

} else {
	echo "Erro incluindo:" . $sql . "<br>" . $conn_cli->error;
	// fecha banco
	$conn_cli->close();
}

?>

</body>
</html>