<!DOCTYPE html>
<html>
<title>Gerador de Recibos</title>


<meta name="viewport" content="width=device-width, initial-scale=1">

<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">

<link rel="stylesheet" type="text/css" href="i_style.css">

<style>

#estilo1 {

	height:300mm;
    width:210mm;
	background: url(imagens/logo_pag.jpg);
	background-repeat: no-repeat;
	background-opacity: 1;
	
	background-size: 100%;
	background-position: top;
	
	margin: auto;
	
	padding: 10mm;
	text-align: center;
	color: black;
	font-size: 20px;
	border: 1px solid black;
	margin: 0px;
}

</style>

	<body>

		<div class="w3-container w3-teal">
		  <h1>Emissor de Recibos</h1>
		</div>

		<?php

		$getid = $_GET['id']; 

		include("i_conecta_recibos.php");
		include("i_numero_extenso.php");
		include("i_formata_cpf.php");

		/* pesquisa dados do recibo */

		$sql_rec = "SELECT id, cpf_titular, cpf_dependente, data_envio, valor, observacao
					FROM $tb_recibos
					WHERE id = '$getid'";
					
		$result_rec = $conn_rec->query($sql_rec);

		$dado_rec = $result_rec->fetch_array();
		
		/* pesquisa dados do titular */

		include("i_conecta_clientes.php");
		
		$cpf_titular = $dado_rec['cpf_titular'];
		
		$sql_tit = "SELECT nome, email
					FROM $tb_clientes
					WHERE cpf = '$cpf_titular'";
		
		$result_tit = $conn_cli->query($sql_tit);
		$dado_tit =  $result_tit->fetch_array();

		/* pesquisa dados do dependente */

		$cpf_dependente = $dado_rec['cpf_dependente'];
		$sql_dep = "SELECT nome
					FROM $tb_clientes
					WHERE cpf = '$cpf_dependente'";

		$result_dep = $conn_cli->query($sql_dep);

		$dado_dep =  $result_dep->fetch_array();

		/* define data por extenso */
		setlocale(LC_TIME, 'portuguese');
		date_default_timezone_set('America/Sao_Paulo');

		$date = date($dado_rec['data_envio']);
		$data_extenso = strftime("%d de %B de %Y", strtotime($date));

		?>

		<form id="estilo1">
		
			<div style="padding-top: 10%;
						padding-bottom: 10%;
						padding-left: 10%;
						padding-right: 10%;">

				<h1 style="text-align=center; font-size: 60px;">RECIBO </h1>
				
				<h3>ref: 2019/<?php echo $dado_rec['id'];?></h3>
					
				<br>
				<br>
				
				<div style="padding-top: 10%; padding-bottom: 20%; text-align: justify;">
					Recebi de <?php echo $dado_tit['nome'];?>, CPF n° <?php echo mask($dado_rec['cpf_titular'],'###.###.###-##');?> o valor total de 
					R$ <?php echo number_format($dado_rec['valor'], 2, ',', '.');?> (<?php echo numero_extenso($dado_rec['valor']);?> reais) referente ao tratamento de psicoterapia.
					
					<?php if ($dado_rec['cpf_dependente'] != null) {?>
						<br> <br>
						CPF do Dependente: <?php echo mask($dado_rec['cpf_dependente'],'###.###.###-##') . "\n" ;?>
						<br>
						Nome do Dependente: <?php echo $dado_dep['nome'] . "\n" ;
					}
					
					if ($dado_rec['observacao'] != null) {?>
						<br>
						<br>
						Obs: <?php echo $dado_rec['observacao'] . "\n";
					}
					if ($dado_rec['cpf_dependente'] == null) {?>
						<br> <br> <br> <br>
					<?php } 
					if ($dado_rec['observacao'] == null) { ?>
						<br> <br> <br> <br>
					<?php } ?>

					<br>
					
				</div>
				<div style="text-align: right;">
					Sem mais,
					<br>
					<br>
					São Bernardo do Campo, <?php echo $data_extenso?>.
				</div>
				
			</div>	
			
		</form>

		<!-- exibe email destino -->
		<div class="w3-left w3-card w3-third  w3-border w3-mobile w3-round w3-padding w3-large w3-orange">

			<i class="material-icons w3-xlarge w3-cell-middle w3-left">arrow_right</i>
			Email destino: <?php 
							if ($dado_tit['email'] != null )
								{ echo $dado_tit['email']; } 
							else 
								{ echo "Nenhum email cadastrado";} 
							?>
		</div>		
		
		<!-- exibe botao gerar PDF -->
		<a 	class="w3-button w3-border w3-mobile w3-round-large w3-padding-large w3-xlarge w3-hover-dark-gray w3-green "
			style="width: 100%;"
			href="rec_emit_pdf.php?id=<?php echo $getid;?>">

			<i class="material-icons w3-xxlarge w3-cell-middle w3-left">save</i>
			Gerar arquivo PDF
		</a>
					
		<!-- exibe botao voltar -->
		<a 	class="w3-button w3-border w3-mobile w3-round-large w3-padding-large w3-xlarge w3-hover-dark-gray w3-pale-green "
			style="width: 100%;"
			href="rec_pesq.php">

			<i class="material-icons w3-xxlarge w3-cell-middle w3-left">home</i>
			Voltar
		</a>
			
	</body>

</html>
