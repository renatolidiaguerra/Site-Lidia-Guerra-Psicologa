<!DOCTYPE html>
<html>
<title>Emissor de Recibos</title>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">

<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">

<link rel="stylesheet" type="text/css" href="i_style.css">

<body>

	<a 	class="w3-button w3-border w3-mobile w3-round-large w3-padding-large w3-xlarge w3-hover-dark-gray w3-orange "
		href="ajuCadastro.php"
		style="width: 100%;">

		<i class="material-icons w3-xxlarge w3-cell-middle w3-left">help</i>
		Como cadastrar um cliente
	</a>
	
	<a 	class="w3-button w3-border w3-mobile w3-round-large w3-padding-large w3-xlarge w3-hover-dark-gray w3-amber "
		style="width: 100%;"
		href="ajuRecibo.php">

		<i class="material-icons w3-xxlarge w3-cell-middle w3-left">help</i>
		Como emitir um Recibo
	</a>

	<a 	class="w3-button w3-border w3-mobile w3-round-large w3-padding-large w3-xlarge w3-hover-dark-gray w3-yellow "
		style="width: 100%;"
		href="index.htm">

		<i class="material-icons w3-xxlarge w3-cell-middle w3-left">home</i>
		Voltar para a tela principal
	</a>

</body>

</html>