<?php
//* ---------------------------
//* criptografa string recebida
//* ---------------------------

function crypto ($entrada)
	{

	$lap1 = base64_encode($entrada);
		
	$lap2 = strrev($lap1);
	
	$lap2 .= date('YmdHis');
	
	$lap3 = base64_encode($lap2);
	
	return $lap3;
	}

function decrypto ($entrada)
	{
	$lap1 = base64_decode($entrada);
	
	$tam = strlen($lap1);
	
	$timestamp = substr($lap1,$tam - 14, 14);
	
	$lap1 = substr($lap1,0,$tam - 14);
	
	$lap2 = strrev($lap1);
	
	$lap3 = base64_decode($lap2);
	
	return $lap3 . "[TIMESTAMP:" . $timestamp . " ]";
	}

?>