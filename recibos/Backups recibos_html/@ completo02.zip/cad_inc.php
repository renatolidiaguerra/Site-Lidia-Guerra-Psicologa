<!DOCTYPE html>
<html>
<title>Emissor de Recibos</title>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">

<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">

<link rel="stylesheet" type="text/css" href="i_style.css">

<body>
	<div class="w3-container w3-teal">
	  <h1>Emissor de Recibos</h1>
	</div>

	<form 	name="nome_formulario" 
			method="post" 
			action="cad_inc_f.php"
			autocomplete="off"		> 
	
	<input type="text"		name="input_cpf" 			required 	placeholder="CPF..."		pattern="[0-9]{11}" 	/> 	
	<input type="text"		name="input_nome" 			required 	placeholder="Nome..."					/> 	
	<input type="text"		name="input_endereco" 					placeholder="Endereço..."				/> 	
	Data Nascimento
	<input type="date" 		name="input_datanascimento" required	placeholder="Data de Nascimento..."		/> 													
	<input type="email"		name="input_email" 			required 	placeholder="E-Mail..."					/> 	
	<input type="text"		name="input_telefone"			 		placeholder="Telefone..."				/>
	<input type="text"		name="input_cpf_titular" 		 		placeholder="CPF titular (se existir)..."	pattern="[0-9]{11}" 	/> 	
	
	<button	type="submit" 
			class="w3-button w3-border w3-mobile w3-round-large w3-padding-large w3-xlarge w3-hover-dark-gray w3-cyan "
			style="width: 100%;">Incluir
		<i class="material-icons w3-xxlarge w3-cell-middle w3-left">add</i>
	</button>

	</form> 

	<a 	class="w3-button w3-border w3-mobile w3-round-large w3-padding-large w3-xlarge w3-hover-dark-gray w3-pale-green "
		style="width: 100%;"
		href="cad.php">

		<i class="material-icons w3-xxlarge w3-cell-middle w3-left">home</i>
		Voltar
	</a>


</body>

</html>
