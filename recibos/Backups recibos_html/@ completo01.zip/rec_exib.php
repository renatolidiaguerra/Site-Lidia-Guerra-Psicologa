<!DOCTYPE html>
<html>
<title>Gerador de Recibos</title>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">

<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">

<link rel="stylesheet" type="text/css" href="i_style.css">

<body>
<form>
	<?php

	$getid = $_GET['id'];

	include("i_conecta_recibos.php"); 

	$sql = "SELECT id, cpf_titular, cpf_dependente, data_envio, valor, observacao
				FROM $tb_recibos
				WHERE id = '$getid'";
				
	$result = $conn_rec->query($sql);

	$dado = $result->fetch_array();

	if ($result->num_rows > 0) {?>
	
		CPF Titular 		<input type="text" 	readonly	placeholder="CPF Titular"		value="<?php echo mask($dado['cpf_titular'],'###.###.###-##');?>"	<br >
		CPF Dependente		<input type="text" 	readonly	placeholder=""					value="<?php echo $dado['cpf_dependente'];?>"> <br >
		Data da Emissão		<input type="text" 	readonly	placeholder="Data de Emissão"	value="<?php echo date('d/m/Y', strtotime($dado['data_envio']));?>"> <br >
		Valor				<input type="text" 	readonly	placeholder="Valor"				value="<?php echo "R$ " . number_format( $dado['valor'] , 2, ',', '.');;?>"> <br >
		Observação			<input type="text" 	readonly	placeholder=""					value="<?php echo $dado['observacao'];?>"> <br >
	<?php 
	}?>

		<a	type="submit" 
				href="rec_emit.php?id=<?php echo $getid;?>"
				class="w3-button w3-border w3-mobile w3-round-large w3-padding-large w3-xlarge w3-hover-dark-gray w3-cyan "
				style="width: 100%;">Emitir Recibo
			<i class="material-icons w3-xxlarge w3-cell-middle w3-left">mail_outline</i>
		</a>
		
		<a 	class="w3-button w3-border w3-mobile w3-round-large w3-padding-large w3-xlarge w3-hover-dark-gray w3-pale-green "
			style="width: 100%;"
			href="rec_pesq.php">

			<i class="material-icons w3-xxlarge w3-cell-middle w3-left">home</i>
			Voltar
		</a>
</form>	
</body>

</html>
<?php	//* formata CPF
	function mask($val, $mask)
		{
		if ($val == null)
				return "";
			
		$maskared = '';
		$k = 0;
		for($i = 0; $i<=strlen($mask)-1; $i++)
			{
			if($mask[$i] == '#')
				{
				if(isset($val[$k]))
					$maskared .= $val[$k++];
				}
			else
				{
				if(isset($mask[$i]))
					$maskared .= $mask[$i];
				}
			}
		return $maskared;
		}
?>