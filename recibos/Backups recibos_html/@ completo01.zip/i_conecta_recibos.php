<?php

// cria variaveis BD
$user = "user01";
$pass = "Gb240820";
$server = "localhost";
$db_name = "cadastro";
$tb_recibos = "recibos";

// cria conexão
$conn_rec = new mysqli($server, $user, $pass, $db_name);
// check conexão
if ($conn_rec->connect_error) {
	die("Erro na conexão: " . $conn_rec->connect_error);
}
?>