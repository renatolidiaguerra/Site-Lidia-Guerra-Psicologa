<!DOCTYPE html>
<html>
<title>Emissor de Recibos</title>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">

<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">

<link rel="stylesheet" type="text/css" href="i_style.css">

<body>
	<div class="w3-container w3-dark-gray w3-text-white">
	  <h1>Emissor de Recibos</h1>
	</div>

<?php

include("i_conecta_clientes.php");

$sql = "SELECT id, cpf, nome, endereco, datanascimento, email , telefone
			FROM $tb_clientes
			ORDER BY nome";
$result = $conn_cli->query($sql);

?> 

	<table class="w3-responsive w3-hoverable">
		<tr class="w3-green	w3-large">
			<th style="width:20px;" ></th>
			<th>ID</th>
			<th>Nome</th>
			<th>Telefone</th>
		</tr>
		<?php while($dado = $result->fetch_array()) { ?>
		<tr class="w3-striped" href="cad_alt_f.php?id=<?php echo $dado['id'];?>">
			<td><a href="cad_alt_f.php?id=<?php echo $dado['id'];?>">	
			<i class="material-icons w3-xlarge w3-cell-middle w3-left">edit</i>
			<td><?php echo $dado['id'];?></td>
			<td><?php echo $dado['nome']; ?></td>
			<td><?php echo $dado['telefone']; ?></td>
		</tr>
		<?php } ?>
	</table>
	<br>
	
	<a 	class="w3-button w3-border w3-mobile w3-round-large w3-padding-large w3-xlarge w3-hover-dark-gray w3-pale-green "
		style="width: 100%;"
		href="cad.php">

		<i class="material-icons w3-xxlarge w3-cell-middle w3-left">home</i>
		Voltar
	</a>
	
</body>
</html>