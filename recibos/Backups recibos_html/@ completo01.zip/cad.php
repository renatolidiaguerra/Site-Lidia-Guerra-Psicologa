<!DOCTYPE html>
<html>
<title>Gerador de Recibos</title>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">

<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
<body>

	<a 	class="w3-button w3-border w3-mobile w3-round-large w3-padding-large w3-xlarge w3-hover-dark-gray w3-purple "
		style="width: 100%;"
		href="cad_inc.php">

		<i class="material-icons w3-xxlarge w3-cell-middle w3-left">person_add</i>
		Inclusão
	</a>
	
	<a 	class="w3-button w3-border w3-mobile w3-round-large w3-padding-large w3-xlarge w3-hover-dark-gray w3-deep-purple "
		style="width: 100%;"
		href="cad_alt.php">

		<i class="material-icons w3-xxlarge w3-cell-middle w3-left">mode_edit</i>
		Alteração
	</button>

	<a 	class="w3-button w3-border w3-mobile w3-round-large w3-padding-large w3-xlarge w3-hover-dark-gray w3-indigo "
		style="width: 100%;"
		href="cad_con.php">

		<i class="material-icons w3-xxlarge w3-cell-middle w3-left">search</i>
		Consulta
	</button>
	
	<a 	class="w3-button w3-border w3-mobile w3-round-large w3-padding-large w3-xlarge w3-hover-dark-gray w3-blue "
		style="width: 100%;"
		href="cad_exc.php">

		<i class="material-icons w3-xxlarge w3-cell-middle w3-left">delete</i>
		Exclusão
	</button>

	<a 	class="w3-button w3-border w3-mobile w3-round-large w3-padding-large w3-xlarge w3-hover-dark-gray w3-light-blue "
		style="width: 100%;"
		href="index.htm">

		<i class="material-icons w3-xxlarge w3-cell-middle w3-left">home</i>
		Menu Principal
	</button>

</body>

</html>