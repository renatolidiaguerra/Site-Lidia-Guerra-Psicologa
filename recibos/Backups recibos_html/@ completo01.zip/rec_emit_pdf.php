<?php 

	require_once 'dompdf/autoload.inc.php';
		
	use Dompdf\Dompdf;

	$dompdf = new Dompdf();

//*	$dompdf = new Dompdf(array('enable_remote' => true));
	
//* ---------------------------------------------------

	$getid = $_GET['id']; 

	include("i_conecta_recibos.php");
	include("i_numero_extenso.php");
	include("i_formata_cpf.php");

/* pesquisa dados do recibo */

	$sql_rec = "SELECT id, cpf_titular, cpf_dependente, data_envio, valor, observacao
				FROM $tb_recibos
				WHERE id = '$getid'";
				
	$result_rec = $conn_rec->query($sql_rec);

	$dado_rec = $result_rec->fetch_array();
	
/* pesquisa dados do titular */

	include("i_conecta_clientes.php");
	
	$cpf_titular = $dado_rec['cpf_titular'];
	
	$sql_tit = "SELECT nome, email
				FROM $tb_clientes
				WHERE cpf = '$cpf_titular'";
	
	$result_tit = $conn_cli->query($sql_tit);
	$dado_tit =  $result_tit->fetch_array();

/* pesquisa dados do dependente */

	$cpf_dependente = $dado_rec['cpf_dependente'];
	$sql_dep = "SELECT nome
				FROM $tb_clientes
				WHERE cpf = '$cpf_dependente'";

	$result_dep = $conn_cli->query($sql_dep);

	$dado_dep =  $result_dep->fetch_array();

/* define data por extenso */
	setlocale(LC_TIME, 'portuguese');
	date_default_timezone_set('America/Sao_Paulo');

	$date = date($dado_rec['data_envio']);
	$data_extenso = strftime("%d de %B de %Y", strtotime($date));

//* ---------------------------------------------------

//*	<img src=\"" . $_SERVER['DOCUMENT_ROOT'] . "/emissorrecibo/imagens/logo_pag.jpg\" style=\"height: 10%; width: 10%;\" />

$html = "
	<!DOCTYPE html>
	<html>
		<title>Gerador de Recibos</title>

		
		<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">

		<link rel=\"stylesheet\" href=\"https://www.w3schools.com/w3css/4/w3.css\">
		<link rel=\"stylesheet\" href=\"https://fonts.googleapis.com/icon?family=Material+Icons\">

		<link rel=\"stylesheet\" type=\"text/css\" href=\"i_style.css\">

		<style>

			html,
			body {
				margin:0;
				padding:0;
				height:100%;
				font-size: 20px;
			}
		</style>



		<body>
		
			<div> 

				<img src=\"imagens/cabecalho.jpg\" style=\"height: auto; width: 100%;\" />

			</div>

			<!-- =============================================== -->

			<div style=\"padding-right: 10%; padding-left: 10%;\">

				<h1 style=\"text-align:center; \">RECIBO</h1>
				
				<h3 style=\"text-align:center; \">ref: 2019/" . $dado_rec['id'] . "</h3>


				<div style=\"padding-top: 5%; padding-bottom: 5%; text-align: justify;\">
				
					Recebi de ". $dado_tit['nome'].", CPF n° ". mask($dado_rec['cpf_titular'],'###.###.###-##');"." o valor total de 
					R$ ". number_format($dado_rec['valor'], 2, ',', '.') ." (". numero_extenso($dado_rec['valor'])." reais) referente ao tratamento de psicoterapia.
					<br>";

					if ($dado_rec['cpf_dependente'] != null) {
						$html = $html . "
						<br> <br>
						CPF do Dependente: " . mask($dado_rec['cpf_dependente'],'###.###.###-##') . "\n" . 
						"<br>
						Nome do Dependente: ". $dado_dep['nome'] . "\n";
					}

					if ($dado_rec['observacao'] != null) {
						$html = $html . "


						Obs: ". $dado_rec['observacao'] . "\n";
					}
					if ($dado_rec['cpf_dependente'] == null) {
						$html = $html . "<br> <br> <br>";
					} 
					if ($dado_rec['observacao'] == null) {
						$html = $html . "<br> <br> <br>";
					}

					$html = $html . "
				</div>
				
				<br>
				
				<div style=\"text-align: right;\">
					Sem mais,

					<br>
					<br>

					São Bernardo do Campo, ".$data_extenso.".
				</div>
				
			</div>
				
			<!-- =============================================== -->
			
			<br>
			<br>

			<div>
			
    			<img src=\"imagens/rodape.jpg\" style=\"height: auto; width: 100%; \" />

			</div>	
			
		</body>
		
	</html>";
//* ---------------------------------------------------
//* ---------------------------------------------------
//*	<img src=\"" . $_SERVER['DOCUMENT_ROOT'] . "/emissorrecibo/imagens/cabecalho.jpg\" style=\"height: auto; width: 100%;\" />
//* ---------------------------------------------------



$dompdf->loadHtml($html);

$dompdf->setPaper('A4', 'portrait');
//* $dompdf->setPaper('A4', 'portrait');
//*                  (array(0, 0, [height],[width])

$dompdf->render();

$path_pdf = "recibos/";
$arquivo = "recibo_id" . $getid . ".pdf";

$modo = 'salvar'; //* salvar ou enviar

if ($modo == 'salvar') {
    //* gera arquivo e salva em diretorio/servidor
    $pdf_string =   $dompdf->output();
    file_put_contents($path_pdf . $arquivo, $pdf_string ); 
    
    //* abre arquivo no diretorio do servidor
    header("location: " . $path_pdf . $arquivo);
    
 //*   $dompdf->stream($path_pdf . $arquivo);
} else {
    $pdf_string =   $dompdf->output();
    file_put_contents($path_pdf . $arquivo, $pdf_string ); 

    //* echo "arquivo gerado com sucesso";
    
    //* ---------------------------------------------------
    //* ---------------------------------------------------
    
    $de_email	= 'psico.lidia@hotmail.com';
    $de_nome	= 'Lidia Guerra Psicologa (via app)';
    $para_email	= $dado_tit['email'];
    $para_nome	= $dado_tit['nome'];
    $corpo  	= '<p>Aqui esta seu recibo. <br><br> Obrigado<br>Lidia Guerra';
    $titulo		= '## Recibo de Psicologia ##';
    $arquivo	= $path_pdf . $arquivo;
    
    //* >>>
     include('rec_emit_email.php');
    //* >>>
}

?>