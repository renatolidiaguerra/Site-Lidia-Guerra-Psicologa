<!DOCTYPE html>
<html>
<title>Gerador de Recibos</title>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">

<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">

<link rel="stylesheet" type="text/css" href="i_style.css">

<body>

	<?php

	$getcpf = $_GET['cpf'];
	$getnome = $_GET['nome'];

	include("i_conecta_recibos.php");

	$sql = "SELECT id, cpf_titular, cpf_dependente, data_envio, valor, observacao
				FROM $tb_recibos
				WHERE cpf_titular = '$getcpf'
				ORDER BY data_envio";
				
	$result = $conn_rec->query($sql);
	
	if ($result->num_rows > 0) { ?>
		<table class="w3-responsive w3-hoverable">
			<tr class="w3-red	w3-large">
				<th style="width:20px;" ></th>
				<th>CPF Titular</th>
				<th>Nome Titular</th>
				<th>Data Envio</th>
				<th>Valor</th>
			</tr>
			<?php while($dado = $result->fetch_array()) { ?>
			<tr>
				<td><a href="rec_exib.php?id=<?php echo $dado['id'];?>">	
					<i class="material-icons w3-xlarge w3-cell-middle w3-left ">email</i></td>
				<td><?php echo mask($dado['cpf_titular'],'###.###.###-##');?></td>
				<td><?php echo $getnome; ?></td>
				<td><?php echo date('d/m/Y', strtotime($dado['data_envio'])); ?></td>
				<td><?php echo "R$ " . number_format( $dado['valor'] , 2, ',', '.');?></td>
				<!--td><a href="f_recibosExibir.php?id=<?php echo $dado['id'];?>">	
					<img src="imagens/next-page.png" 	alt="Consultar Recibos" 	style="width:20px;height:20px;border:0;"></a>		
				</td-->
			</tr>
			<?php } ?>
		</table>
	<?php 
	} else { ?>
		<div class="w3-center w3-card w3-red  w3-border w3-mobile w3-round-large w3-padding-large w3-xlarge">
			Nenhum nome encontrado
		</div> 
	<?php
	}?>

	<a 	class="w3-button w3-border w3-mobile w3-round-large w3-padding-large w3-xlarge w3-hover-dark-gray w3-green "
		style="width: 100%;"
		href="rec_novo.php?cpf=<?php echo $getcpf;?>&nome=<?php echo $getnome;?>">

		<i class="material-icons w3-xxlarge w3-cell-middle w3-left">add</i>
		Criar Recibo
	</a>
	
	<a 	class="w3-button w3-border w3-mobile w3-round-large w3-padding-large w3-xlarge w3-hover-dark-gray w3-pale-green "
		style="width: 100%;"
		href="rec_pesq.php">

		<i class="material-icons w3-xxlarge w3-cell-middle w3-left">home</i>
		Voltar
	</a>
</body>
</html>

<?php
	//* formata CPF
	function mask($val, $mask)
		{
		if ($val == null)
				return "";
			
		$maskared = '';
		$k = 0;
		for($i = 0; $i<=strlen($mask)-1; $i++)
			{
			if($mask[$i] == '#')
				{
				if(isset($val[$k]))
					$maskared .= $val[$k++];
				}
			else
				{
				if(isset($mask[$i]))
					$maskared .= $mask[$i];
				}
			}
		return $maskared;
		}
?>