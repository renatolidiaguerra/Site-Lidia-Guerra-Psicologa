<!DOCTYPE html>
<html>
<title>Emissor de Recibos</title>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">

<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">

<link rel="stylesheet" type="text/css" href="i_style.css">

<body>

	<a 	id="botao_a"
		href="ajuCadastro.php">
		<i class="material-icons w3-xxlarge w3-cell-middle w3-left">help</i>
		
		Como cadastrar um cliente
	</a>
	
	<a 	id="botao_b"
		href="ajuRecibo.php">
		<i class="material-icons w3-xxlarge w3-cell-middle w3-left">help</i>
		
		Como emitir um Recibo
	</a>

	<a 	id="botao_voltar"
		href="index.htm">
		<i class="material-icons w3-xxlarge w3-cell-middle w3-left">home</i>
		
		Voltar para a tela principal
	</a>
	
<!--                ---------------------------------                -->
	
	<a 	id="botao_voltar"
		href="#">
		<i class="material-icons w3-xxlarge w3-cell-middle w3-left">help</i>
		Voltar
	</a>
	
	<a 	id="botao_ok"
		href="#">
		<i class="material-icons w3-xxlarge w3-cell-middle w3-left">home</i>
		ok
	</a>
	
	<a 	id="botao_a"
		href="#">
		<i class="material-icons w3-xxlarge w3-cell-middle w3-left">home</i>
		A
	</a>
	
	<a 	id="botao_b"
		href="#">
		<i class="material-icons w3-xxlarge w3-cell-middle w3-left">home</i>
		B
	</a>
	
	<a 	id="botao_c"
		href="#">
		<i class="material-icons w3-xxlarge w3-cell-middle w3-left">home</i>
		C
	</a>	
	
	<a 	id="botao_d"
		href="#">
		<i class="material-icons w3-xxlarge w3-cell-middle w3-left">home</i>
		D
	</a>	
	
	<a 	id="botao_e"
		href="#">
		<i class="material-icons w3-xxlarge w3-cell-middle w3-left">home</i>
		E
	</a>
</body>	
</html>