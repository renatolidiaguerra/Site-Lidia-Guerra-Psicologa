<!DOCTYPE html>
<html>
<title>Emissor de Recibos</title>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">

<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">

<link rel="stylesheet" type="text/css" href="i_style.css">

<body>

	<div id="botao_a">
		Como cadastrar um cliente
	</div>
	
	<div id="botao_b" style="text-align: left; ">

		 1- Clique em "Cadastro <br>
		 2- Clique em Incluir <br>
		 3- Preencha os dados necessários<br>
		 4- Confirme	<br>
		
	</div>

	<a 	id="botao_voltar"
		href="aju.php">

		<i class="material-icons w3-xxlarge w3-cell-middle w3-left">home</i>
		Voltar
	</a>

</body>

</html>