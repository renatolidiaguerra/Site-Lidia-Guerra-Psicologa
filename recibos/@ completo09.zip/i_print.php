<?php
function exibe($iprint) {
return;
	echo $iprint;
	
	echo "<br>";
	
}
?>